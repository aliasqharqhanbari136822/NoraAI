package com.nora.ai

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var speak: Button
    private lateinit var image: Button
    private lateinit var settings: Button
    private lateinit var tts: TextToSpeech
    private var selectedImage: Uri? = null
    private var speakingEnabled = true
    private val client = OkHttpClient()
    private val prefs by lazy { getSharedPreferences("nora", MODE_PRIVATE) }
    private val history by lazy { prefs.getStringSet("history", LinkedHashSet())?.toMutableList() ?: mutableListOf() }

    private val picker = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri -> selectedImage = uri; if (uri != null) addSystem("تصویر انتخاب شد؛ همراه پیام بعدی ارسال می‌شود.") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        restoreHistory()
    }

    override fun onDestroy() { tts.stop(); tts.shutdown(); super.onDestroy() }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(16,16,16,10); setBackgroundColor(Color.WHITE)
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text="نورا"; textSize=28f; gravity=Gravity.CENTER; setTextColor(Color.BLACK) }
        settings = Button(this).apply { text="⚙" }
        top.addView(title, LinearLayout.LayoutParams(0,70,1f)); top.addView(settings, LinearLayout.LayoutParams(60,70))
        root.addView(top)

        chat = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(6,6,6,6) }
        val scroll = ScrollView(this).apply { addView(chat) }
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        val tools = LinearLayout(this)
        image = Button(this).apply { text="تصویر" }
        speak = Button(this).apply { text="🎙" }
        tools.addView(image, LinearLayout.LayoutParams(0,55,1f))
        tools.addView(speak, LinearLayout.LayoutParams(0,55,1f))
        root.addView(tools)

        val row = LinearLayout(this)
        input = EditText(this).apply { hint="پیامت را بنویس..."; textSize=17f; gravity=Gravity.RIGHT; minLines=1; maxLines=5 }
        send = Button(this).apply { text="ارسال" }
        row.addView(input, LinearLayout.LayoutParams(0,-2,1f)); row.addView(send, LinearLayout.LayoutParams(-2,-2))
        root.addView(row)
        setContentView(root)

        send.setOnClickListener { sendMessage() }
        image.setOnClickListener { picker.launch("image/*") }
        speak.setOnClickListener { startVoice() }
        settings.setOnClickListener { showSettings() }
    }

    private fun sendMessage() {
        val msg=input.text.toString().trim()
        if(msg.isEmpty()) return
        input.text.clear(); addUser(msg); send.isEnabled=false
        val server=prefs.getString("server","https://api.openai.com/v1")!!
        val key=prefs.getString("key","")!!
        if(key.isBlank()) { addNora("ابتدا در تنظیمات کلید API را وارد کن."); send.isEnabled=true; return }

        val content = org.json.JSONArray()
        content.put(JSONObject().put("type","input_text").put("text",msg))
        // برای تصویر واقعی، فایل را به data URL تبدیل و در همین content قرار می‌توان توسعه داد.
        val body=JSONObject()
            .put("model", prefs.getString("model","gpt-5.6-luna"))
            .put("instructions","تو نورا هستی. فارسی، دقیق، مستقیم و کاربردی پاسخ بده.")
            .put("input", JSONObject().put("role","user").put("content",content))
        val req=Request.Builder().url(server.trimEnd('/')+"/responses")
            .addHeader("Authorization","Bearer $key")
            .addHeader("Content-Type","application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).enqueue(object:Callback{
            override fun onFailure(call:Call,e:IOException){ addNora("خطا در اتصال: ${e.message}"); runOnUiThread{send.isEnabled=true} }
            override fun onResponse(call:Call,response:Response){
                response.use {
                    val raw=it.body?.string()?:""
                    val text=extractOutput(raw)
                    addNora(if(it.isSuccessful) text else "خطای API: $text")
                    runOnUiThread{send.isEnabled=true}
                    if(it.isSuccessful) saveHistory("شما: $msg\nنورا: $text")
                }
            }
        })
    }

    private fun extractOutput(raw:String):String {
        return try {
            val o=JSONObject(raw)
            val direct=o.optString("output_text")
            if(direct.isNotBlank()) direct else {
                val out=o.optJSONArray("output") ?: return raw
                val sb=StringBuilder()
                for(i in 0 until out.length()){
                    val item=out.optJSONObject(i) ?: continue
                    val c=item.optJSONArray("content") ?: continue
                    for(j in 0 until c.length()) sb.append(c.optJSONObject(j)?.optString("text","") ?: "")
                }
                sb.toString().ifBlank{raw}
            }
        } catch(_:Exception){ raw }
    }

    private fun startVoice() {
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECORD_AUDIO),50); return
        }
        if(!SpeechRecognizer.isRecognitionAvailable(this)){ addSystem("تشخیص گفتار روی این گوشی در دسترس نیست."); return }
        val sr=SpeechRecognizer.createSpeechRecognizer(this)
        val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fa-IR")
        }
        sr.setRecognitionListener(object:android.speech.RecognitionListener{
            override fun onResults(b:Bundle?){ input.setText(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?:""); sr.destroy() }
            override fun onError(e:Int){ sr.destroy() }
            override fun onReadyForSpeech(p:Bundle?){}; override fun onBeginningOfSpeech(){}; override fun onRmsChanged(r:Float){}
            override fun onBufferReceived(b:ByteArray?){}; override fun onEndOfSpeech(){}; override fun onPartialResults(b:Bundle?){}
            override fun onEvent(t:Int,p:Bundle?){}
        })
        sr.startListening(intent)
    }

    private fun showSettings() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,10,30,10)}
        val server=EditText(this).apply{hint="API URL";setText(prefs.getString("server","https://api.openai.com/v1"))}
        val key=EditText(this).apply{hint="OpenAI API Key";setText(prefs.getString("key",""));inputType=0x81}
        val model=EditText(this).apply{hint="Model";setText(prefs.getString("model","gpt-5.6-luna"))}
        val clear=Button(this).apply{text="پاک کردن حافظه"}
        box.addView(server);box.addView(key);box.addView(model);box.addView(clear)
        val d=AlertDialog.Builder(this).setTitle("تنظیمات نورا").setView(box).setPositiveButton("ذخیره"){_,_->prefs.edit().putString("server",server.text.toString()).putString("key",key.text.toString()).putString("model",model.text.toString()).apply()}.setNegativeButton("لغو",null).create()
        clear.setOnClickListener{prefs.edit().remove("history").apply();chat.removeAllViews();d.dismiss()}
        d.show()
    }

    private fun addUser(s:String)=addBubble("شما: $s",false)
    private fun addNora(s:String){addBubble("نورا: $s",true);if(speakingEnabled) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"nora")}
    private fun addSystem(s:String)=addBubble(s,true)
    private fun addBubble(s:String,nora:Boolean){runOnUiThread{chat.addView(TextView(this).apply{text=s;textSize=17f;setTextColor(Color.DKGRAY);setPadding(10,12,10,12);gravity=Gravity.RIGHT})}}
    private fun saveHistory(s:String){val list=prefs.getStringSet("history",LinkedHashSet())?.toMutableList()?:mutableListOf();list.add(s);while(list.size>50)list.removeAt(0);prefs.edit().putStringSet("history",list.toSet()).apply()}
    private fun restoreHistory(){history.forEach{addSystem(it)}}
    override fun onInit(status:Int){tts.language=Locale("fa","IR")}
}
